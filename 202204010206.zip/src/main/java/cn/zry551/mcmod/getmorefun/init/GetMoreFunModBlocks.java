
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.mcmod.getmorefun.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;

import java.util.List;
import java.util.ArrayList;

import cn.zry551.mcmod.getmorefun.block.BlackGemOreBlock;
import cn.zry551.mcmod.getmorefun.block.BlackGemBlockBlock;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class GetMoreFunModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block BLACK_GEM_ORE = register(new BlackGemOreBlock());
	public static final Block BLACK_GEM_BLOCK = register(new BlackGemBlockBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.mcmod.getmorefun.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import java.util.List;
import java.util.ArrayList;

import cn.zry551.mcmod.getmorefun.item.BlackGemToolsSwordItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemToolsShovelItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemToolsPickaxeItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemToolsHoeItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemToolsAxeItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemItem;
import cn.zry551.mcmod.getmorefun.item.BlackGemArmorArmorItem;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class GetMoreFunModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item BLACK_GEM = register(new BlackGemItem());
	public static final Item BLACK_GEM_ORE = register(GetMoreFunModBlocks.BLACK_GEM_ORE, GetMoreFunModTabs.TAB_C_GET_MORE_FUN);
	public static final Item BLACK_GEM_BLOCK = register(GetMoreFunModBlocks.BLACK_GEM_BLOCK, GetMoreFunModTabs.TAB_C_GET_MORE_FUN);
	public static final Item BLACK_GEM_TOOLS_PICKAXE = register(new BlackGemToolsPickaxeItem());
	public static final Item BLACK_GEM_TOOLS_AXE = register(new BlackGemToolsAxeItem());
	public static final Item BLACK_GEM_TOOLS_SWORD = register(new BlackGemToolsSwordItem());
	public static final Item BLACK_GEM_TOOLS_SHOVEL = register(new BlackGemToolsShovelItem());
	public static final Item BLACK_GEM_TOOLS_HOE = register(new BlackGemToolsHoeItem());
	public static final Item BLACK_GEM_ARMOR_ARMOR_HELMET = register(new BlackGemArmorArmorItem.Helmet());
	public static final Item BLACK_GEM_ARMOR_ARMOR_CHESTPLATE = register(new BlackGemArmorArmorItem.Chestplate());
	public static final Item BLACK_GEM_ARMOR_ARMOR_LEGGINGS = register(new BlackGemArmorArmorItem.Leggings());
	public static final Item BLACK_GEM_ARMOR_ARMOR_BOOTS = register(new BlackGemArmorArmorItem.Boots());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}

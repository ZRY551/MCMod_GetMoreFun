
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.mcmod.getmorefun.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class GetMoreFunModTabs {
	public static CreativeModeTab TAB_C_GET_MORE_FUN;

	public static void load() {
		TAB_C_GET_MORE_FUN = new CreativeModeTab("tabc_get_more_fun") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.COMPOSTER);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}

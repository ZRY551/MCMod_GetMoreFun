
package cn.zry551.mcmod.getmorefun.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import cn.zry551.mcmod.getmorefun.init.GetMoreFunModTabs;

public class BlackGemItem extends Item {
	public BlackGemItem() {
		super(new Item.Properties().tab(GetMoreFunModTabs.TAB_C_GET_MORE_FUN).stacksTo(64).fireResistant().rarity(Rarity.COMMON));
		setRegistryName("black_gem");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}

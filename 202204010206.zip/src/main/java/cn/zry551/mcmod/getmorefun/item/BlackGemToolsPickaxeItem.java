
package cn.zry551.mcmod.getmorefun.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import cn.zry551.mcmod.getmorefun.init.GetMoreFunModTabs;
import cn.zry551.mcmod.getmorefun.init.GetMoreFunModItems;

public class BlackGemToolsPickaxeItem extends PickaxeItem {
	public BlackGemToolsPickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 10086;
			}

			public float getSpeed() {
				return 15f;
			}

			public float getAttackDamageBonus() {
				return 0f;
			}

			public int getLevel() {
				return 6;
			}

			public int getEnchantmentValue() {
				return 14;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(GetMoreFunModItems.BLACK_GEM));
			}
		}, 1, -3f, new Item.Properties().tab(GetMoreFunModTabs.TAB_C_GET_MORE_FUN).fireResistant());
		setRegistryName("black_gem_tools_pickaxe");
	}
}
